import 'package:untitled1/opcoesvestidos.dart';
import 'package:untitled1/detail_page.dart';
import 'package:untitled1/login.dart';
import 'package:untitled1/carrinho.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
        home: SegundaPagina()
    ),
  );
}