import 'package:untitled1/domain/Catalogodoopcoesvestidos.dart';

class Database {
  static List<Catalogodoopcoesvestidos > pacotes = [
    Catalogodoopcoesvestidos (
      urlImage:  'https://mirak.jetassets.com.br/produto/20240722213142_7509992491_D.jpg',
      titulo: 'VESTIDO DIANA MIDI AZUL MARINO',
      preco: '359,00',
    ),
  ];
}
class Database2 {
  static List<Catalogodoopcoesvestidos> pacotes = [
    Catalogodoopcoesvestidos(
      urlImage: 'https://mirak.jetassets.com.br/produto/multifotos/20240824190908_7791992209_DM.jpg',
      titulo: 'VESTIDO CARLOTA PRETO',
      preco: '270,00',
    ),
  ];
}
class Database3 {
  static List<Catalogodoopcoesvestidos > pacotes = [
    Catalogodoopcoesvestidos (
      urlImage:  'https://mirak.jetassets.com.br/produto/20241007185918_3470996530_D.jpg',
      titulo: 'VESTIDO NOEMIA OFF WHITE',
      preco: '320,00',
    ),
  ];
}