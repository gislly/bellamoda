import 'package:untitled1/domain/Catalogodovestido3.dart';

class Database {
  static List infos = [
    Catalogodovestido3(
      urlImage:
      'https://mirak.jetassets.com.br/produto/20241007185918_3470996530_D.jpg',
      nome:   'VESTIDO NOEMIA OFF WHITE',
      descricao:
      'O Vestido Noemia Off White é a peça perfeita para brilhar em qualquer ocasião. Confeccionado em um tecido leve e fluido, ele proporciona conforto e elegância. O detalhe de babados e a estampa floral trazem um toque romântico, enquanto o corte midi valoriza a silhueta. Combine com sandálias ou sapatilhas para um look encantador!',
      preco: 320.00,
      tamanhos: 'PP  P  M  G  GG',
      marca: 'BELLA MODA',
    ),
  ];
}
