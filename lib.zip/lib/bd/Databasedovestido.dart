import 'package:untitled1/domain/Catalogodovestido.dart';

class Database {
  static List infos = [
    Catalogodovestido(
      urlImage:
      'https://mirak.jetassets.com.br/produto/20240722213142_7509992491_D.jpg',
      nome:  'VESTIDO DIANA MIDI AZUL MARINO',
      descricao:
      'Eleve seu estilo com o Vestido Diana midi azul marinho, confeccionado em tecido azul de alta qualidade. Com um comprimento curto e um corte ajustado que valoriza a silhueta, é a escolha perfeita para diversas ocasiões. Seu design elegante e sofisticado torna-o um item indispensável no guarda-roupa.',
      preco: 359.00,
      tamanhos: 'PP  P  M  G  GG',
      marca: 'BELLA MODA',
    ),
  ];
}
