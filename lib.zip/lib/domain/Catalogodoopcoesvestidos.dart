class Catalogodoopcoesvestidos {
  String urlImage;
  String titulo;
  String preco;

  Catalogodoopcoesvestidos({
    required this.urlImage,
    required this.titulo,
    required this.preco,
  });
}
