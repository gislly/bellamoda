
class Catalogodovestido3 {
  String urlImage;
  String nome;
  String marca;
  double preco;
  String tamanhos;
  String descricao;

  Catalogodovestido3({
    required this.urlImage,
    required this.nome,
    required this.marca,
    required this.preco,
    required this.tamanhos,
    required this.descricao,
  });
}