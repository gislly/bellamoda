
class Catalogodovestido {
  String urlImage;
  String nome;
  String marca;
  double preco;
  String tamanhos;
  String descricao;

  Catalogodovestido({
    required this.urlImage,
    required this.nome,
    required this.marca,
    required this.preco,
    required this.tamanhos,
    required this.descricao,
  });
}
